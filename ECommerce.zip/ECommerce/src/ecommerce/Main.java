/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ecommerce;

/**
 *
 * @author koket
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        SmartPhone smartphone = new SmartPhone();
        smartphone.price(250);
        
        Tablet tablet = new Tablet();
        tablet.price(1500);
        
        Laptop laptop = new Laptop();
        laptop.price(1250);
        
        
        
    }
    
}
