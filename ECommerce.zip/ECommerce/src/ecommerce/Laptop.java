/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommerce;

/**
 *
 * @author koket
 */
public class Laptop implements Price{
    @Override
    public void price (double price){
        System.out.println("The price of your laptop will be: " + price);
    }
}


// Interface done