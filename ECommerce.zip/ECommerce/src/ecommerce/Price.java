/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ecommerce;

/**
 *
 * @author koket
 */
public interface Price {
    // Which will have a method consisting a double for the price.
    
    void price (double price);
    
}
